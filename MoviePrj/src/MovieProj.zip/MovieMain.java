package MovieProj;
import static MovieProj.Login.Login.loginMenu;

public class MovieMain {
    public static void main(String[] args) {
        loginMenu();
    }
}


